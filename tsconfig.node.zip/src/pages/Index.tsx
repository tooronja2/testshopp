
import Home from './Home';

const Index = () => {
  return <Home />;
};

export default Index;
